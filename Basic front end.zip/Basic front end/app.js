/****
   SIT209 - Software Engineering 2: Developing IoT Applications
   Exercise:       Basic Front End
   Student Name:   Ereena Bagga
   Student ID:     2010993040 
 ****/

// Array declaration. 
// Gets the item sacks from local storage, converts it into a JSON object, and stores it in the array sacks
const sacks = JSON.parse(localStorage.getItem('sacks')) || [];

// Iterate over the array sacks and create a new row in the table for each object
sacks.forEach(function(sack) {
  $('#sacks tbody').append(`
    <tr>
      <td>${sack.uid}</td>
      <td>${sack.entry_date}</td>
      <td>${sack.expiration_date}</td>
      <td>${sack.location}</td>
      <td>${sack.weight}</td>
      <td>${sack.moisture}</td>
      <td>${sack.cost}</td>
      <td>${sack.floor_location}</td>
    </tr>`
  );
});

// Add a new sack to the list of sacks on button click
$('#add-sack').on('click', function() {
  const uid = $('#uid').val();
  const entry_date = $('#entry_date').val();
  const expiration_date = $('#expiration_date').val();
  const location = $('#location').val();
  const weight = $('#weight').val();
  const moisture = $('#moisture').val();
  const cost = $('#cost').val();
  const floor_location = $('#floor_location').val();
  sacks.push({ uid, entry_date, expiration_date, location, weight, moisture, cost, floor_location });
  localStorage.setItem('sacks', JSON.stringify(sacks));
  location.href = 'sack-list.html';
});